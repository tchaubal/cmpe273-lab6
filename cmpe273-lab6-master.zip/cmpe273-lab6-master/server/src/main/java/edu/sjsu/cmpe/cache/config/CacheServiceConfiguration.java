package edu.sjsu.cmpe.cache.config;

import com.yammer.dropwizard.config.Configuration;

public class CacheServiceConfiguration extends Configuration {

}
